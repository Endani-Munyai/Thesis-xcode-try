//
//  products.h
//  Thesis xcode try
//
//  Created by Endani Munyai on 2024. 03. 18..
//

#ifndef products_h
#define products_h

#include <stdio.h>
typedef struct Product *p_Product;
typedef struct Purchase *p_Purchase;
typedef struct Ledger *p_Ledger;
typedef struct Inventory *p_Inventory;


#endif /* products_h */
