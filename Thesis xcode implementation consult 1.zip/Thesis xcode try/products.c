//
//  products.c
//  Thesis xcode try
//
//  Created by Endani Munyai on 2024. 03. 01..
//

#include "products.h"
#include <stdlib.h>
#include <time.h>
#define small_n (3)
#define medium_n (5)
#define large_n (12)

/* Structures */
struct Product
{
	int ID;
	int Count;
};

struct Purchase
{
	p_Product products[1];
};

// outgoing products
struct Ledger
{
	p_Purchase purchases[1];
	int number_purchases;
};

// floating stock/inventory
struct Inventory
{
	p_Product products[1];
	int number_different_products;
};


/* Functions */
p_Inventory generateInverntory (int products)
{
	p_Inventory p_stock;
	int a,
		b,
		c;
	srand(time(0));
	
	p_stock = malloc(sizeof(struct Inventory) + sizeof(struct Product) * products);
	p_stock->number_different_products = products;
	
	for (int i=0; i<products; i++)
	{
		a = rand();
		b = rand();
		c = rand();
		p_stock->products[i]->Count = (a%small_n) * (b%medium_n) * (c*large_n) * 20;
	}
	return p_stock;
}

void destroyInventory (p_Inventory p)
{
	
}

p_Purchase generatePurchase (p_Inventory stock,
							p_Ledger record)
{
	p_Purchase p;
	srand(time(0));
	
	int number_different_products = stock->number_different_products;
	int a = rand();
	int b = 0;
	
	p = malloc(sizeof(struct Purchase)+ (sizeof(struct Product) * number_different_products));
	
	for (int i = 0; i<number_different_products; i++)
	{
		p->products[i]->ID = i;
		if (a/7)
		{
			b = a % small_n;
			if (b > stock->products[i]->Count)
			{
				b = stock->products[i]->Count;
			}
			p->products[i]->Count = b;
		}
		else if (a/11)
		{
			b =a % medium_n;
			if (b > stock->products[i]->Count)
			{
				b = stock->products[i]->Count;
			}
			p->products[i]->Count = b;
		}
		else if (a/13)
		{
			b =a % large_n;
			if (b > stock->products[i]->Count)
			{
				b = stock->products[i]->Count;
			}
			p->products[i]->Count = b;
		}
		else
		{
			p->products[i]->Count = 0;
		}
		srand(time(0));
		a = rand();
	}
	return p;
};

void destroyPurchase (p_Purchase p)
{
	
}

int stockremaining(p_Inventory stock,
				   p_Ledger ledger)
{
	int a = stock->number_different_products;
	for (int i = 0; i<a; i++)
	{
		if (stock->products[i]->Count == 0)
			return 0;
	}
	
	return 1;
}

p_Ledger generateLedger (p_Inventory stock)
{
	p_Ledger p;
	
	p = malloc(sizeof(struct Ledger)+ sizeof(struct Purchase) * stock->number_different_products);
	p->number_purchases = 1
	while (stockremaining(stock))
	{
		
	}
	return p;
}

void destroyLedger (p_Ledger p)
{
	
}


