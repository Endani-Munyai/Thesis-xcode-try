//
//  graph original adjacency list.h
//  Thesis xcode try
//
//  Created by Endani Munyai on 2024. 03. 08..
//

#ifndef graph_original_adjacency_list_h
#define graph_original_adjacency_list_h

#include <stdio.h>

typedef struct GraphStruct *p_graph;

#endif /* graph_original_adjacency_list_h */
