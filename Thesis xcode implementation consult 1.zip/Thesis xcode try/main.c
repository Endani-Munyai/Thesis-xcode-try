//
//  main.c
//  Thesis xcode try
//
//  Created by Endani Munyai on 2024. 03. 06..
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
	
	return 0;
}
