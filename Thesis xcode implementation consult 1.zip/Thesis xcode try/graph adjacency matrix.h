//
//  graph adjacency matrix.h
//  Thesis xcode try
//
//  Created by Endani Munyai on 2024. 03. 15..
//

#ifndef graph_adjacency_matrix_h
#define graph_adjacency_matrix_h

#include <stdio.h>

typedef struct GraphMatrixStruct *p_graph_matrix;

#endif /* graph_adjacency_matrix_h */
